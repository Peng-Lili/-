function[E1,E2]=getE(Kfile,Pfile,Dfile,p_value)
    K=Kfile;
    D=Dfile;
    P=Pfile;
    p=p_value;
    a=1.5;
    w=9.027;
    b=-0.543;
    E1=zeros(17,17);
    E2=zeros(17,17);
    for r=1:17
        for s=1:17 
            x1=K(r,s)/a;
            x2=K(s,r)/a;
            x3sum=0;
           for o=1:17
             if o~=s
                x32=(D(o,r)+D(r,s)).^(-b)*K(r,s);
                x3sum=x3sum+x32;
             end
           end
           x3=0;
           for o=1:17
             if o~=s 
                x31=K(o,r)/a;
                x32=((D(o,r)+D(r,s)).^(-b)*K(r,s))/x3sum;
                x3=x3+x31*x32;
             end
           end
           x3=x3*w*p;
           E1(r,s)=x1+x2*P(r,s)+x3;
           E2(r,s)=x1+x2*0.6+x3;
            
        end
    end
end