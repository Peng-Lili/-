[T1,~,~] = xlsread('Tij_part1_2.xls');
[T2,~,~] = xlsread('Tij_part2_2.xls');
[D,~,~] = xlsread('Dij.xlsx');
K=(T1+T2)/1.5;
p0=3.255;
p1=-0.024;
p2=-0.135;
P=[];
for i=1:17
    for j=1:17
        s1=p0+p1*K(i,j)+p2*D(i,j);
        P(i,j)=exp(s1)/(1+exp(s1));
    end
end
 xlswrite('need_one_2.xls',P)
