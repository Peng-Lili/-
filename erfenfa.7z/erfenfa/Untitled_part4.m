
[T1,~,~] = xlsread('Tij_part1_2.xls');
[T2,~,~] = xlsread('Tij_part2_2.xls');
[D,~,~] = xlsread('Dij.xlsx');
[P,~,~] = xlsread('need_one_2.xls');
K=(T1+T2)/1.5;
[E1,E2]=getE(K,P,D,1);
xlswrite('need_two_E1_1.xls',E1);
xlswrite('need_two_E2_1.xls',E2);
[E1,E2]=getE(K,P,D,0.8);
xlswrite('need_two_E1_0.8.xls',E1);
xlswrite('need_two_E2_0.8.xls',E2);
[E1,E2]=getE(K,P,D,0.5);
xlswrite('need_two_E1_0.5.xls',E1);
xlswrite('need_two_E2_0.5.xls',E2);
[E1,E2]=getE(K,P,D,0.3);
xlswrite('need_two_E1_0.3.xls',E1);
xlswrite('need_two_E2_0.3.xls',E2);



            
            
        
