[D,~,~] = xlsread('Dij.xlsx');
[NUM,~,~] = xlsread('ab.xlsx');
A=NUM(1:end,2);
B=NUM(1:end,3);
[Q,~,~] = xlsread('Qi.xlsx');
Q1=Q(1:end,2);
Q2=Q(1:end,3);
C=[];
BAI=zeros(17,1);
for i=1:17
    sum=0;
    g=1;
    k=1;
    i
    for j=1:17
       if B(j,1)~=0        
          d=D(i,j);
          aj=exp(B(j,1));         
          sum=sum+d.^g*aj;     
       end
    end
    sum   
    while abs(sum-1)>0.0001
        if sum<1
            g=g+0.0001;
            sum=0;
            k=k+1;
            for j=1:17
                if B(j,1)~=0        
                    d=D(i,j);
                    aj=exp(B(j,1));         
                    sum=sum+d.^g*aj;     
                end
            end
            sum
           
     
        else 
            g=g-0.0001;
            sum=0;
            k=k+1;
            for j=1:17
                if B(j,1)~=0        
                    d=D(i,j);
                    aj=exp(B(j,1));         
                    sum=sum+d.^g*aj;     
                end
            end
            sum
        end 
        if k>100000
            break
        end
    end
   BAI(i,1)=g; 
end
T=zeros(17,17);
for i=1:17
    for j=1:17
        if B(j,1)~=0           
            d=D(i,j);
            aj=B(j,1);
            p=d.^BAI(i,1)*exp(aj);
            T(i,j)=Q1(i,1)*p;
        end
    end
end
xlswrite('Tij_part1_2.xls',T)